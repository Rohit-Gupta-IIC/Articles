from stemmers import porter2            #importing poter2 stemming nad Lemmatisation algorithm  
from espeak import espeak               #importing eapeak to facilitate text to speech  
import time                             #importing time to facilitate time gap  
  
def change_state(door_state, text):  
      
    if isValid(text) == False:         #if text is not valid then show the current door_state   
        return door_state  
  
    open_key = ['open','door']  
    close_key = ['close','door']  
          
    stem_cmd = [porter2.stem(i) for i in text]  #  
  
    if door_state == False:            #if door_state is false the open the door  
        key = open_key  
    elif door_state == True:            #if door_state is true the close the door  
        key = close_key  
      
    for w in key:  
        if w not in stem_cmd:  
            print("invalid command")    #if the input is other than what is defined then print and speak "inalid command"  
            espeak.set_voice("ru")  
            espeak.synth("invalid command")  
            time.sleep(1)  
            return door_state  
      
    door_state = not door_state  
  
    if door_state == True:              #opens the door  
        print("Door Opened")  
        espeak.set_voice("ru")  
        espeak.synth("Door Opened")  
        time.sleep(1)  
    else:                               #closes the door  
        print("Door Closed")  
        espeak.set_voice("ru")  
        espeak.synth("Door Closed")  
        time.sleep(1)  
      
    return door_state  
      
# Checks whether the natural language input is valid or not.  
def isValid(text):                                
    stemmed = [porter2.stem(i) for i in text]  
                                                        #applying the porter2 algorithm  
    if (len(text) == 1) or ('open' in stemmed and 'close' in stemmed):  
        print("Invalid command.")  
        espeak.set_voice("ru")  
        espeak.synth("Invalid Command")  
        time.sleep(1)  
        return False  
  
    return True  