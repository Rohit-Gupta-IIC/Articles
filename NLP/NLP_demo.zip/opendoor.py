from changeDoorState import change_state    #importing the changeDoorstate module  
from espeak import espeak                   #importing espeak to facilitate text to speech  
import time                                 #importing time to give the time delay  
  
door_state = False                          #door is closed  
                                            # True => door is opened  
                                            # False => door is closed  
f=open("NLP.txt","r+")                      #Opening the NLP.txt file  
while True:   
  
    if door_state == True:                  #if Door_state is true the print and speak door opened  
        print("Door state: Opened")  
        espeak.set_voice("ru")  
        espeak.synth("Door state: Opened")  
        time.sleep(1)         
    else:                                   #if Door_state is true the print and speak door closed  
        print("Door state: Closed")  
        espeak.set_voice("ru")  
        espeak.synth("Door state: Closed")  
        time.sleep(1)  
      
    cmd=f.readline()                        #read a line from the NLP.txt  
    command = cmd.split()                   #split each line into separte words  
    if len(command) == 0:  
        continue  
    door_state = change_state(door_state, command) 